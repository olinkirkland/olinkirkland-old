import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.*;

public class DirectoryTextFormatter {
    public static void main(String[] args) {
		System.out.println("FORMATTING " + args[0]);
		String directoryPart = args[0];
		int totalVotes = 15;
		ArrayList lineArray = new ArrayList();
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy  hh:mm aaa");
		Date date = new Date();
		String printReady = "";
		try {
			BufferedReader inputFile = new BufferedReader(new FileReader(
					"Raw_Directories_" + directoryPart + ".txt"));
			String line = null;
			while ((line = inputFile.readLine()) != null) {
				lineArray.add(line);
			}

			ArrayList contentList = new ArrayList();

			for (int i = 0; i < 7; i++) {
				lineArray.remove(0);
			}
			lineArray.remove(lineArray.size() - 1);
			lineArray.remove(lineArray.size() - 1);

			int lineIndex = 1;
			String lineIndexStr = "";
			for (int i = 0; i < lineArray.size(); i++) {
				lineIndexStr = Integer.toString(lineIndex);
				contentList.add(reformatLine((String) lineArray.get(i)));
				printReady += reformatLine((String) lineArray.get(i));
				if (i < lineArray.size() - 1) {
					printReady += "\r\n";
				}
				lineIndex++;
			}
			System.out.println(printReady);
			FileWriter fWriter = null;
			BufferedWriter writer = null;
			fWriter = new FileWriter("../Index/" + directoryPart + ".txt");
			writer = new BufferedWriter(fWriter);
			writer.write(printReady);
			writer.close();

			System.out.println("\nDirectory Updated.");

		} catch (IOException e) {
		}
	}

	public static String reformatLine(String line) {
		boolean validLine = false;
		if (line.length() > 39) {
			validLine = true;
			line = line.substring(39);
		} else {
			validLine = false;
		}
		if (!validLine) {
			line = "";
		}
		line = line.substring(0, line.length() - 4);
		return line;
	}

	public static String reformatLine2(String line) {
		boolean validLine = false;
		if (line.length() > 20) {
			validLine = true;
			// line = line.substring(39);
		} else {
			validLine = false;
		}
		if (!validLine) {
			line = "";
		}
		line = line.substring(0, 20);
		return line;
	}
}